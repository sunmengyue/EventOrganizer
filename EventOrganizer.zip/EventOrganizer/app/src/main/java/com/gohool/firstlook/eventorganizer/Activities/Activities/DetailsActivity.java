package com.gohool.firstlook.eventorganizer.Activities.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.gohool.firstlook.eventorganizer.R;



public class DetailsActivity extends AppCompatActivity {
    private TextView itemName;
    private TextView itemAddress;
    private TextView dateAdded;
    private int eventId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        itemName = findViewById(R.id.itemNameDet);
        itemAddress = findViewById(R.id.addressDet);
        dateAdded = findViewById(R.id.dateAddedDet);

        Bundle bundle = getIntent().getExtras();
        if(bundle != null) {
            itemName.setText(bundle.getString("name"));
            itemAddress.setText(bundle.getString("address"));
            dateAdded.setText(bundle.getString("date added this event"));
            eventId = bundle.getInt("id");
        }

    }
}
