package com.gohool.firstlook.eventorganizer.Activities.Activities;

import android.app.LauncherActivity;
import android.os.Bundle;

import com.gohool.firstlook.eventorganizer.Activities.Data.DatabaseHandler;
import com.gohool.firstlook.eventorganizer.Activities.Model.Event;
import com.gohool.firstlook.eventorganizer.Activities.UI.RecyclerViewAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;

import com.gohool.firstlook.eventorganizer.R;

import java.util.ArrayList;
import java.util.List;

public class ListActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private RecyclerViewAdapter recyclerViewAdapter;
    private List<Event> eventList;
    private List<Event> listEvents;
    private DatabaseHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        db = new DatabaseHandler(this);
        recyclerView = findViewById(R.id.recyclerViewId);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        eventList = new ArrayList<>();
        listEvents = new ArrayList<>();

        //Get Items from database
        eventList = db.getAllEvents();

        for(Event c : eventList) {
            Event event = new Event();
            event.setName(c.getName());
            event.setAddress("Address: " + c.getAddress());
            event.setId(c.getId());
            event.setDateItemadded("Added on: " + c.getDateItemadded());

            listEvents.add(event);
        }

        recyclerViewAdapter = new RecyclerViewAdapter(this, listEvents);
        recyclerView.setAdapter(recyclerViewAdapter);
        recyclerViewAdapter.notifyDataSetChanged();
    }


}
