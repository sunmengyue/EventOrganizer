package com.gohool.firstlook.eventorganizer.Activities.Model;

public class Event {
    private String name;
    private String address;
    private String dateItemadded;
    private int id;

    public Event() {
    }

    public Event(String name, String address, String dateItemadded, int id) {
        this.name = name;
        this.address = address;
        this.dateItemadded = dateItemadded;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDateItemadded() {
        return dateItemadded;
    }

    public void setDateItemadded(String dateItemadded) {
        this.dateItemadded = dateItemadded;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
