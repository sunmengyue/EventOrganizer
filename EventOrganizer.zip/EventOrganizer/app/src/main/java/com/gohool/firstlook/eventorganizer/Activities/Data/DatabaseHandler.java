package com.gohool.firstlook.eventorganizer.Activities.Data;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.ListView;

import com.gohool.firstlook.eventorganizer.Activities.Model.Event;
import com.gohool.firstlook.eventorganizer.Activities.Utils.Constants;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import androidx.annotation.Nullable;

public class DatabaseHandler extends SQLiteOpenHelper {

    private Context ctx;
    public DatabaseHandler(@Nullable Context context) {
        super(context, Constants.DATABASE_NAME, null, Constants.DATABASE_VERSION);
        this.ctx = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + Constants.TABLE_NAME + "(" + Constants.KEY_ID +
                "INTEGER PRIMARY KEY, " + Constants.EVENT_NAME + " TEXT, " + Constants.DATE_TIME_NAME
                + " LONG, " + Constants.ADDRESS_NAME + " TEXT);";
        db.execSQL(CREATE_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + Constants.TABLE_NAME);

        //create a new one
        onCreate(db);

    }

    /*
    * CRUD Operations: create, read, update, delete methods
    * */

    //Add Event
    public void addEvent(Event event) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Constants.EVENT_NAME, event.getName());
        values.put(Constants.DATE_TIME_NAME, java.lang.System.currentTimeMillis());
        values.put(Constants.ADDRESS_NAME, System.currentTimeMillis());

        //insert the row
        db.insert(Constants.TABLE_NAME, null, values);
        Log.v("added event item", "Yessss");

    }

    //Get an event item
    public Event getEvent(int id) {

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(Constants.TABLE_NAME, new String[]{Constants.KEY_ID,
                        Constants.EVENT_NAME, Constants.ADDRESS_NAME, Constants.DATE_TIME_NAME},
                Constants.KEY_ID + "=?" ,
                new String[]{String.valueOf(id)}, null, null, null, null);

        if(cursor != null)
            cursor.moveToFirst();
            Event event = new Event();
            event.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(Constants.KEY_ID))));
            event.setName(cursor.getString(cursor.getColumnIndex(Constants.EVENT_NAME)));
            event.setAddress(cursor.getString(cursor.getColumnIndex(Constants.ADDRESS_NAME)));

            //Convert timestamp to something readable
            java.text.DateFormat dateFormat = java.text.DateFormat.getInstance();
            String formatedDate = dateFormat.format(new Date(cursor.getLong(cursor.getColumnIndex(Constants.DATE_TIME_NAME))).getTime());
            event.setDateItemadded(formatedDate);

        return event;

    }

    //Get all events
    public List<Event> getAllEvents() {
        SQLiteDatabase db = this.getReadableDatabase();
        List<Event> eventsList = new ArrayList<>();
        Cursor cursor = db.query(Constants.TABLE_NAME, new String[]{Constants.KEY_ID, Constants.EVENT_NAME, Constants.ADDRESS_NAME,
                        Constants.DATE_TIME_NAME}, null, null, null, null,
                Constants.DATE_TIME_NAME + " DESC");

        if(cursor.moveToFirst()) {
            do {
                Event event = new Event();
                event.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(Constants.KEY_ID))));
                event.setName(cursor.getString(cursor.getColumnIndex(Constants.EVENT_NAME)));
                event.setAddress(cursor.getString(cursor.getColumnIndex(Constants.ADDRESS_NAME)));

                //Convert timestamp to something readable
                java.text.DateFormat dateFormat = java.text.DateFormat.getInstance();
                String formatedDate = dateFormat.format(new Date(cursor.getLong(cursor.getColumnIndex(Constants.DATE_TIME_NAME))).getTime());
                event.setDateItemadded(formatedDate);

                //Add to the event list
                eventsList.add(event);

            } while(cursor.moveToNext());
        }
        return eventsList;
    }

    //Update Event
    public int updateEvent (Event event) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Constants.EVENT_NAME, event.getName());
        values.put(Constants.DATE_TIME_NAME, java.lang.System.currentTimeMillis());
        values.put(Constants.ADDRESS_NAME, System.currentTimeMillis());

        //update row
        return db.update(Constants.TABLE_NAME, values, Constants.KEY_ID + "=?",
                new String[]{String.valueOf(event.getId())});
    }

    //Delete Event
    public void deleteEvent(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(Constants.TABLE_NAME, Constants.KEY_ID + "=?",
                new String[]{String.valueOf(id)});
        db.close();

    }

    //Get count
    public int getEventCount(){

        String countQuery = "SELECT * FROM " + Constants.TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        return cursor.getCount();
    }


}
