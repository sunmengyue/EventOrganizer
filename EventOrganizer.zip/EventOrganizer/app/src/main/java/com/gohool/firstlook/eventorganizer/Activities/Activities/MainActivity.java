package com.gohool.firstlook.eventorganizer.Activities.Activities;

import android.content.Intent;
import android.os.Bundle;

import com.gohool.firstlook.eventorganizer.Activities.Data.DatabaseHandler;
import com.gohool.firstlook.eventorganizer.Activities.Model.Event;
import com.gohool.firstlook.eventorganizer.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private AlertDialog.Builder dialogBuilder;
    private AlertDialog dialog;
    private EditText eventItem;
    private EditText address;
    private Button saveButton;
    private DatabaseHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHandler(this);
        byPassActivity();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                createPopupDialog();


            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    // Popup Aleart
    private void createPopupDialog () {

        dialogBuilder = new AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.popup, null);
        eventItem = view.findViewById(R.id.event_item);
        address = view.findViewById(R.id.eventAddress);
        saveButton = view.findViewById(R.id.saveButton);

        dialogBuilder.setView(view);
        dialog = dialogBuilder.create();
        dialog.show();

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!eventItem.getText().toString().isEmpty() && !address.getText().toString().isEmpty()) {
                    saveEventToDB(v);
                }


            }
        });

    }

    private void saveEventToDB(View v) {
        Event event = new Event();
        String newEvent = eventItem.getText().toString();
        String newAddress = eventItem.getText().toString();

        event.setName(newEvent);
        event.setAddress(newAddress);

        //Save to DB
        db.addEvent(event);
        Snackbar.make(v, "Event Saved!", Snackbar.LENGTH_LONG).show();

        //Log.v("Item added ID: ", String.valueOf(db.getEventCount()));
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                dialog.dismiss();

                //start a new activity
                startActivity(new Intent(MainActivity.this, ListActivity.class));
            }
        }, 1000); //wait 1 second after the alert
    }

    public void byPassActivity() {
        //Check if the db is empty. If not, go to list acitivity to show all items
        if (db.getEventCount() > 0) {
            startActivity(new Intent(MainActivity.this, ListActivity.class));
            finish();
        }
    }


}
