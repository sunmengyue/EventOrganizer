package com.gohool.firstlook.eventorganizer.Activities.UI;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.NetworkInfo;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.gohool.firstlook.eventorganizer.Activities.Activities.DetailsActivity;
import com.gohool.firstlook.eventorganizer.Activities.Data.DatabaseHandler;
import com.gohool.firstlook.eventorganizer.Activities.Model.Event;
import com.gohool.firstlook.eventorganizer.R;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.TooltipCompat;
import androidx.recyclerview.widget.RecyclerView;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
    private Context context;
    private List<Event> eventItems;
    private AlertDialog.Builder alertDialoguBuilder;
    private AlertDialog dialog;
    private LayoutInflater inflater;

    public RecyclerViewAdapter(Context context, List<Event> eventItems) {
        this.context = context;
        this.eventItems = eventItems;
    }

    @NonNull
    @Override
    public RecyclerViewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_row, parent, false);
        return new ViewHolder(view, context);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewAdapter.ViewHolder holder, int position) {

        Event event = eventItems.get(position);
        holder.eventItemName.setText(event.getName());
        holder.address.setText(event.getAddress());
        holder.dateAdded.setText(event.getDateItemadded());

    }

    @Override
    public int getItemCount() {
        return eventItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView eventItemName;
        public TextView address;
        public TextView dateAdded;
        public Button editButton;
        public Button deleteButton;


        public int id;


        public ViewHolder(@NonNull View view, Context ctx) {
            super(view);

            context = ctx;
            eventItemName = view.findViewById(R.id.name);
            address = view.findViewById(R.id.address);
            dateAdded = view.findViewById(R.id.dateAdded);

            deleteButton = view.findViewById(R.id.deleteButton);
            TooltipCompat.setTooltipText(deleteButton, "Delete");

            editButton = view.findViewById(R.id.editButton);
            TooltipCompat.setTooltipText(editButton, "Edit");

            editButton.setOnClickListener(this);
            deleteButton.setOnClickListener(this);


            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //go to next screen
                    int position = getAdapterPosition();
                    Event event = eventItems.get(position);
                    Intent intent = new Intent(context, DetailsActivity.class);
                    intent.putExtra("name", event.getName());
                    intent.putExtra("address", event.getAddress());
                    intent.putExtra("id", event.getId());
                    intent.putExtra("date added this event", event.getDateItemadded());
                    context.startActivity(intent);
                }
            });

        }


        @Override
        public void onClick(View v) {

            switch (v.getId()) {
                case R.id.editButton:

                    int position = getAdapterPosition();
                    Event event = eventItems.get(position);

                    editItem(event);

                    break;

                case R.id.deleteButton:

                    position = getAdapterPosition();
                    event = eventItems.get(position);
                    deleteItem(event.getId());

                    break;


            }

        }



        public void deleteItem(final int id) {
            //create an alert dialog
            alertDialoguBuilder = new AlertDialog.Builder(context);
            inflater = LayoutInflater.from(context);
            View view = inflater.inflate(R.layout.confirmation_dialog, null);

            Button noButton = view.findViewById(R.id.noButton);
            Button yesButton = view.findViewById(R.id.yesButton);

            alertDialoguBuilder.setView(view);
            dialog = alertDialoguBuilder.create();
            dialog.show();

            noButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();

                }
            });

            yesButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //delete the item
                    DatabaseHandler db = new DatabaseHandler(context);
                    //delete item
                    db.deleteEvent(id);
                    eventItems.remove(getAdapterPosition());
                    notifyItemRemoved(getAdapterPosition());

                    dialog.dismiss();

                }
            });

        }

        public void editItem(final Event event) {

            alertDialoguBuilder = new AlertDialog.Builder(context);

            inflater = LayoutInflater.from(context);
            final View view = inflater.inflate(R.layout.popup, null);

            final EditText eventItem =  view.findViewById(R.id.event_item);
            final EditText eventItemAddress = view.findViewById(R.id.eventAddress);
            final TextView title = view.findViewById(R.id.title);

            title.setText("Edit Event");
            Button saveButton =  view.findViewById(R.id.saveButton);

            alertDialoguBuilder.setView(view);
            dialog = alertDialoguBuilder.create();
            dialog.show();

            saveButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    DatabaseHandler db = new DatabaseHandler(context);

                    //Update item
                    event.setName(eventItem.getText().toString());
                    event.setAddress(address.getText().toString());

                    if (!eventItem.getText().toString().isEmpty()
                            && !eventItemAddress.getText().toString().isEmpty()) {
                        db.updateEvent(event);
                        notifyItemChanged(getAdapterPosition(), event);
                    }else {
                        Snackbar.make(view, "Add Grocery and Quantity", Snackbar.LENGTH_LONG).show();
                    }

                    dialog.dismiss();

                }
            });

        }
    }
}
