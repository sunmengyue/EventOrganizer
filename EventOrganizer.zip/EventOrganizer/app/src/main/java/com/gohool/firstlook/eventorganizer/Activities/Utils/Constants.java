package com.gohool.firstlook.eventorganizer.Activities.Utils;

public class Constants {
    public static final String DATABASE_NAME = "eventsdb";
    public static final int DATABASE_VERSION = 1;
    public static final String TABLE_NAME = "events_tbl";

    //table columns
    public static final String EVENT_NAME = "name";
    public static final String DATE_TIME_NAME = "date_and_time";
    public static final String ADDRESS_NAME = "address_name";
    public static final String KEY_ID = "rowid";
}
